//
//  ViewController.swift
//  Egg
//
//  Created by Ibrahim Usmani on 2/11/21.
//

import UIKit
import AVFoundation
import AudioToolbox

class ViewController: UIViewController {

    @IBOutlet weak var progressView:
    UIProgressView!
    @IBOutlet weak var labelOutput: UILabel!
    
    var eggTimes = ["Soft" : 3, "Medium" : 5, "Hard" : 7]
    
    var timer = Timer()
    
    var startTime = 0
    var totalTime = 0
    
    @IBAction func buttonPressed(_ sender:
        UIButton) {
        
        startTime = 0
        progressView.progress = 0.0
        
        timer.invalidate()
        let hardness = sender.currentTitle!
        
        
        totalTime = eggTimes[hardness]!
        labelOutput.text = hardness
        
        timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(updateCounter), userInfo: nil, repeats: true)
        
        // Plays audio at the beginning of the timer
        AudioServicesPlaySystemSound(SystemSoundID(1110))
    }
    
    @objc func updateCounter() {
        //example functionality
        if startTime < totalTime {
           
            startTime += 1
            
            progressView.progress = Float(startTime)/Float(totalTime)
        }
        else {
            
            labelOutput.text = "Done!"
            
            timer.invalidate()
            
            // Plays audio at the end of the timer
            AudioServicesPlaySystemSound(SystemSoundID(1111))
        }
    
    }
    
    }
